# Local coding E2E evaluation

This opt-in developer harness measures an Orbit coding agent using real Ollama
inference. It is separate from deterministic `npm test`. It does not establish a
SWE-bench leaderboard score. The [results index](../e2e/results/README.md)
summarizes the dated local experiments and links to their tracked reports,
machine-readable summaries and submitted patches.

## Prerequisites and small cases

Use Node.js 22.16 or newer for the E2E host scripts, npm dependencies installed
with `npm ci`, Docker Desktop running Linux containers, and Ollama on the Mac.
`test:e2e:unit` also needs a local `python3` executable for the test-wrapper checks.
The agent image uses pinned Node.js 22; the Orbit package's minimum Node version
is unchanged. No cloud credentials or existing Orbit sessions are needed.

```sh
ollama pull gemma4:12b
ollama pull ornith-1.5:9b
npm run e2e:build
npm run test:e2e:unit
npm run test:e2e:graders
caffeinate -i npm run test:e2e:ollama
```

`caffeinate` is optional on macOS and prevents idle sleep during a measurement.
The default matrix runs four cases, three times each, for both named models,
serially. A failed case makes Mocha fail but does not skip later trials. A smaller
probe can be selected explicitly:

```sh
ORBIT_E2E_MODELS=gemma4:12b ORBIT_E2E_REPETITIONS=1 ORBIT_E2E_CASE=read npm run test:e2e:ollama
```

Case IDs are `read`, `single-file`, `test-repair`, and `multi-file`.
`OLLAMA_HOST_URL` changes host-side metadata access (default
`http://127.0.0.1:11434`); `ORBIT_E2E_OLLAMA_HOST` changes the agent's endpoint
(default `http://host.docker.internal:11434`). `ORBIT_E2E_IMAGE` selects a built
agent image. Do not expose Ollama publicly to run these tests.

Before an agent run, the host compares a fingerprint of the current Orbit source,
package manifests and worker against the files baked into the selected image.
Rebuild the local image after source changes; for Verified, rebuild the SWE base
image and then the Verified image. A mismatch stops the run before inference, so
stale binaries cannot silently produce misleading context-summary metrics. The
matching fingerprint is saved as `agentSourceSha256` in each run record.

Each trial receives a new container, workspace and in-memory Session. Only the
fixture and run configuration are mounted read-only. Orbit and tools execute as
the image's non-root user. The container has limited CPU, memory and process
count, no added capabilities, and no host Docker socket or home directory.
The model runs on the Mac; containers call Ollama over Docker Desktop networking.

Small cases have a 240-second Run budget, 12 tool iterations (13 model calls) and a host timeout with
30 seconds of grace. SIGINT/SIGTERM remove tracked containers. Normal and failed
runs stop the container before copying artifacts and removing it. SIGKILL or a
host crash cannot run cleanup: inspect `docker ps -a --filter name=orbit-e2e-`
and remove only the matching abandoned experiment containers. Images and logs
are retained intentionally; no global Docker prune is performed.

The host grades copied artifacts in a new network-disabled, read-only container.
Hidden checks are streamed to that grader and never mounted in the solving
container. The recovery case also requires an observed failing test followed by
a successful rerun and preserves its visible test file. Grader controls verify
that original bugs fail, correct code passes, and `process.exit(0)` cannot bypass
the completion marker. These are cooperative coding evaluations, not a hardened
sandbox against a malicious agent. Model-generated code and diagnostic files
are not trusted security attestations.

Mocha/Chai provide assertions and reporting. Docker CLI control was selected over
Testcontainers for this first implementation: it uses the existing dependencies,
permits explicit stop/copy/remove ordering, and also fits the official Python
harness. No new npm dependency or production API is introduced.

## One official SWE-bench instance

The selected Lite problem is `sympy__sympy-20590`. The dataset revision and source
commit are fixed in `e2e/prepare-swe.py`; the official evaluation image is pinned
by digest in `e2e/swebench.mjs`. Its architecture is **amd64** and Docker Desktop
emulates it on this ARM64 Mac. This is not native ARM execution. The successful
reference-patch run verifies this specific combination, not all SWE-bench images.

Prepare a host Python virtual environment using Python 3.10 or newer (the macOS
system Python 3.9 is insufficient). Set `PYTHON` to an installed compatible
interpreter. The official harness runs on the host and creates its own disposable
evaluation container. Never mount the host Docker socket inside a container.

```sh
mkdir -p tmp/e2e
# Set PYTHON to a Python >=3.10 executable before this command.
"$PYTHON" -m venv tmp/e2e/venv
git clone --branch v4.1.0 --depth 1 https://github.com/SWE-bench/SWE-bench.git tmp/e2e/SWE-bench
git -C tmp/e2e/SWE-bench rev-parse HEAD
# Expected: 726c5461e2ef52d83cf1ea2107870a8bb3328d57
tmp/e2e/venv/bin/pip install ./tmp/e2e/SWE-bench
npm run eval:swebench -- prepare
tmp/e2e/venv/bin/pip freeze > tmp/e2e/swe/python-dependencies.txt
npm run eval:swebench -- gold
docker build -f e2e/SweAgent.Dockerfile -t orbit-e2e:swe .
ORBIT_E2E_IMAGE=orbit-e2e:swe caffeinate -i npm run eval:swebench -- solve ornith-1.5:9b
# Use the actual predictions path printed by solve:
npm run eval:swebench -- grade tmp/e2e/swe/solve-ornith-1.5-9b-<uuid>/predictions.jsonl
```

`ORBIT_SWE_PYTHON` overrides the host virtual-environment interpreter. Commands
use the active Docker context endpoint. `gold` explicitly pulls the pinned amd64
image and gives it an experiment-owned alias for the official harness.

`solve` requires a successful gold result for the current dataset file hash. It
extracts only `problem_statement` and a source archive at `base_commit`. The agent
gets neither repository history, the reference patch, evaluation test patch,
nor dataset records. The trusted host extracts the resulting diff into official
JSONL fields `instance_id`, `model_name_or_path`, `model_patch`. A fresh official
container applies and grades that patch. The evaluator report determines
resolution; process exit zero alone is insufficient. The SWE solving budget is
900 seconds with unlimited tool iterations and model calls by default, context
32768, and thinking disabled by default.
`ORBIT_SWE_THINK=true` enables thinking for a separately recorded experiment.
Small cases use context 16384 and thinking disabled. Both use temperature 0.6, top-p 0.95,
num_predict 4096 and seed 42. Settings are recorded for every trial.

The agent network is available for the host Ollama connection. The prompt forbids
retrieving solutions, but external access is not technically allowlisted. This is
a local diagnostic experiment, not a contamination-proof benchmark submission.
Agent dependencies differ from the official grader's pinned environment; solver
test errors and official grading outcomes must be distinguished.

## Evidence and interpretation

`tmp/e2e/runs/<timestamp>-small/` holds environment metadata, model digests and
quantization, each prompt/options, Run and Session results, streamed model/tool
events, copied artifacts, grader logs and incremental `summary.json`.
`tmp/e2e/swe/` holds pinned dataset metadata, private reference material, official
reports and predictions. **Do not mount this parent directory into the agent.**
These ignored files are local evidence: preserve them separately for a machine
handoff. Curated dated reports, JSON summaries and submitted prediction patches
are tracked under [`e2e/results/`](../e2e/results/README.md). A fresh clone has
those compact records, but not the full logs, workspaces, datasets or hidden
grading material under `tmp/e2e/`.

Read `grade.json` / summary status for final outcomes. `resolved` requires both a
completed Run and independent success; `unresolved` includes incorrect work and
exhausted model budgets. `runtime-error` describes Orbit execution/close failures;
`environment-error` or `timeout` describes infrastructure/host deadlines;
`grading-error` means the judge did not produce a usable result. Raw `run.json`
status describes execution only and can say `runtime-error` for a budget stop;
the final grader explicitly classifies that stop as unresolved. An incomplete
response can omit token accounting; `usageComplete: false` means the reported
usage is only a lower bound. Report all planned trials, not only successful ones.

Seed reuse reduces one source of variation but does not guarantee deterministic
inference. Three repetitions per fixture are diagnostic samples, not a statistical
estimate of general coding ability. Public model benchmark claims use other
scaffolds, budgets and environments and must not be substituted for these results.

The harness reuses Agent/Run, Session, coding tools and the Ollama adapter. It is
an additive developer evaluation, separate from workflow-selection/evaluation
product APIs; no durable product schema, public API, execution policy, or safety
contract changes. An ADR is therefore unnecessary for these test-local changes.
A future provider-options API or safety-sensitive tool error redesign needs its
own proposed ADR and approval before implementation.

An empty prediction is handled by the official harness as `empty_patch_ids`, with no test execution. The wrapper records it as unresolved with `gradingDisposition: skipped-empty-patch`; it never calls that a successfully graded patch.

## Recovery and completion experiment

The small-case default evaluation strategy is `coding-recovery-v1`. SWE-bench retains `baseline`: the recovery strategy did not improve the measured SWE attempts. It supplies
known environment facts, asks the agent to re-read after an exact-text edit
failure, preserve test exit status, and finish after focused checks pass. These
are test-host instructions; they contain no case solution, reference patch or
hidden test information. Orbit's default runtime limits and product prompts are
unchanged. Use `ORBIT_E2E_STRATEGY=baseline` to reproduce the original prompts.

`ORBIT_E2E_ROUNDS` changes the small-case budget (default 12, maximum 100).
SWE-bench always runs with unlimited tool iterations, tool rounds and model
calls; `ORBIT_SWE_ROUNDS` is no longer read. The 900-second elapsed-time
deadline and cleanup remain active. Historical finite-budget results remain
useful evidence, but cannot be reproduced with the current SWE-bench runner.
Each run records its strategy and prompt hash.

```sh
# Three repetitions per small case/model, improved instructions, original budget:
caffeinate -i npm run test:e2e:ollama

# Run SWE-bench without an iteration ceiling and grade the printed prediction.
ORBIT_E2E_STRATEGY=baseline ORBIT_SWE_THINK=false ORBIT_E2E_IMAGE=orbit-e2e:swe caffeinate -i npm run eval:swebench -- solve ornith-1.5:9b
```

`metrics` records started/completed model calls, tool calls/errors, repeated failed
calls with identical tool name/input JSON, and completed-response Ollama loading,
prompt evaluation and generation durations. Interrupted calls contribute no
invented response duration. `execution` includes the observed command elapsed
time and timeout-callback overrun. These help locate delay; they cannot establish
whether a long gap was host sleep, scheduling, transport or inference without
further evidence. Diagnostic metrics never replace independent grading.

Changing these test-host prompts and limits is a local evaluation change, not an
architecture change. Safety-sensitive edit error disclosure or product-wide
budget changes remain separate design work requiring an approved ADR.

A repeated failed call is a diagnostic count, not proof of an unproductive loop:
rerunning a failing test after a partial fix can be appropriate. Inspect tool
names, edits and test outputs before attributing that count to failed recovery.

The measured SWE configuration used the original prompt, 50 iterations and
thinking disabled. It completed in 41 tool calls and passed official grading in
one trial. This historical configuration is not the current default: the SWE
evaluation now has no round limit and retains the elapsed-time deadline. The
[follow-up report](../e2e/results/2026-09-25-recovery.md) also records the
unsuccessful recovery-prompt trials.

## Three pinned Verified problems

`e2e/swebench/*.json` contains a preselected three-repository diagnostic sample.
Set `ORBIT_SWE_CASE` to one manifest to isolate its dataset, gold report, solver
workspaces and official grading under `tmp/e2e/verified/<instance_id>`. Omitting
it retains the existing Lite problem and its separate directory. A manifest
must specify Verified's immutable revision/base commit and a matching official
image digest; mutable tags and mismatched prepared instances are rejected.

Use the existing pinned host Python harness from the setup above. Build the
solver image once; its Python dependencies support the three selected source
trees without including reference patches or grading data:

```sh
docker build -f e2e/VerifiedAgent.Dockerfile -t orbit-e2e:verified .
export ORBIT_SWE_CASE=e2e/swebench/django__django-15731.json
npm run eval:swebench -- prepare
npm run eval:swebench -- gold
ORBIT_E2E_IMAGE=orbit-e2e:verified ORBIT_E2E_STRATEGY=baseline ORBIT_SWE_THINK=false caffeinate -i npm run eval:swebench -- solve ornith-1.5:9b
# Use the predictions path printed by solve, keeping ORBIT_SWE_CASE unchanged:
npm run eval:swebench -- grade <predictions.jsonl>
```

Repeat with `pytest-dev__pytest-10051.json` and
`sphinx-doc__sphinx-10323.json`. Run serially to avoid inference contention.
Do not replace a problem after seeing an unsuccessful solution. The original
prompt, 50 iterations, 900-second Run budget, context 32768 and thinking disabled
are retained. No product runtime defaults change. The solver uses a source
snapshot and a generic Python environment, not the official per-problem test
environment; local test setup failures must be distinguished from official
patch grading failures. Record image ID and `pip freeze` alongside results,
since transitive Python dependencies are not fully locked by the Dockerfile.

Saved batch predictions are standard JSONL. The example below uses the tracked
`e2e/results/2026-09-25-verified-predictions.jsonl`. To regrade one saved prediction
through this single-instance wrapper, extract its row without changing the patch:

```sh
python3 - <<'PYTHON'
import json
from pathlib import Path
root = Path('tmp/e2e/verified/replay')
root.mkdir(parents=True, exist_ok=True)
for line in Path('e2e/results/2026-09-25-verified-predictions.jsonl').read_text().splitlines():
    row = json.loads(line)
    (root / (row['instance_id'] + '.jsonl')).write_text(line + '\n')
PYTHON
ORBIT_SWE_CASE=e2e/swebench/django__django-15731.json npm run eval:swebench -- grade tmp/e2e/verified/replay/django__django-15731.jsonl
```

Prepare the matching dataset first on a new machine. Change both the manifest
and JSONL filename to regrade the other two problems. A replay is a new grading
run of the existing patch, not a new model attempt.

## Repository preflight

Verified solving now checks the pristine source in a separate network-disabled
container before making any Ollama request. It verifies imports resolve under
`/workspace`, records installed Python dependencies, and runs a public smoke
suite selected by repository (not by hidden grading tests). Failure is recorded
as `environment-error` in the attempt's `preflight/report.json` and metadata;
no model attempt is counted as completed. The preflight copy is disposable and
does not modify the solver's initial source or leak gold/test patches.

Rebuild `e2e/VerifiedAgent.Dockerfile` when using this check. Its PYTHONPATH selects
the target source even when a command is launched outside the repository root.
The added `py` dependency supports the selected pytest source, and Pygments is
pinned for the selected Sphinx version. This is still a bounded smoke check, not
proof that every repository test passes. Local harness changes do not alter
product APIs, authorization or runtime defaults and do not require a new ADR.

For the pinned pytest 7.2 archive, preparation creates its missing generated
`src/_pytest/_version.py` before the initial snapshot. The path and exact contents
are recorded in `preparation`; an existing file is never overwritten. Other
pytest versions fail closed until they have a supported profile. Alabaster and
Pygments are pinned to versions compatible with the selected Sphinx source.
Source copies preserve relative symbolic links instead of rewriting them to host
paths. Public smoke checks for Django, pytest and Sphinx passed locally after
these environment corrections; they are not official issue-resolution scores.

## Preserving local test failures

The Verified image includes `orbit-test`, a test-local command wrapper:

```sh
orbit-test --timeout 120 --tail 12000 -- python3 -m pytest -p no:cacheprovider tests/test_example.py -q
```

It executes an argument vector directly, displays at most the requested tail
bytes, and returns the test process's exit status. A timeout kills the process
group and returns 124; launch failure returns 127. Every invocation saves the full
combined output and a JSON result under `/output/test-runs`, outside the patch.
Use its printed `ORBIT_TEST_RESULT` rather than piping a test command through
`tail`. Orbit's general-purpose Bash tool remains unchanged. This wrapper is a
convenience, not a security boundary or a claim that the model used it.

## Independent deliverable quality

Before saving the official JSONL prediction, Verified solving excludes known
generated Python caches from the diff and records their paths in
`excludedGeneratedPaths`. The original workspace is retained. Verified solving
then writes `quality/quality.json` against that original workspace. The host
compares the initial and final files, flags generated Python caches and changed
symlinks, and selects changed public `tests/**/test*.py` or
`testing/**/test*.py` files. It runs those files in a fresh network-disabled
container. Existing test files also run on the initial source, so pre-existing
failures are reported as `baseline-failure`, not silently attributed to the
patch. Added test failures, deleted test files and unwanted generated files
produce `quality-failed`. A run with no eligible tests is `not-measured`.
Infrastructure failures and deadlines are `environment-error`.

This is a separate diagnostic from official `resolved`: passing it does not
prove the fix is correct, and agent-edited tests are not trusted grading tests.
It does not discover every possible generated artifact or test naming convention.
Quality checks do not rewrite the submitted patch. They still report generated
files that were excluded from submission.

Inspect an earlier attempt without modifying its files:

```sh
ORBIT_E2E_IMAGE=orbit-e2e:verified-guarded node e2e/quality.mjs \
  e2e/swebench/sphinx-doc__sphinx-10323.json \
  tmp/e2e/verified/sphinx-doc__sphinx-10323/<attempt>/agent \
  tmp/e2e/quality-replay/<unique-run>
```

On the saved September 25 baseline, this check detected Sphinx's failing added
regression and six cache files despite official resolution. The corresponding
original public test file passed in the corrected environment. Django's modified
tests passed; pytest had no changed eligible tests and was marked `not-measured`.

## Controlled completion instructions

`ORBIT_E2E_STRATEGY=verified-tests-v1` adds only the prepared-environment and
`orbit-test` instructions to the original issue prompt.
`ORBIT_E2E_STRATEGY=verified-focused-v1` adds completion criteria to that exact
control: finish after a focused regression and the affected existing test module
pass, expand only for a concrete related failure, and report unresolved failures.
`verified-focused-v2` keeps those criteria and explicitly asks for the next
response to be final, without further tool calls, after the focused checks finish.
This remains a prompt-level experiment; normal completion still requires the
model to return a response without tool calls.
These are opt-in SWE evaluation strategies; `baseline` remains the default and
Orbit's product prompt and execution limits are unchanged.

For a context compaction interval diagnostic, set
`ORBIT_E2E_CONTEXT_TRIGGER_RATIO` to a ratio strictly greater than the default
0.65 and below 0.95. The ratio is applied to the derived input budget only in the
isolated E2E worker; it does not change Orbit's defaults or persisted profile.
For example, compare the default run with a run at 0.80 while holding the model,
problem, strategy and generation settings fixed. The worker records the derived
profile in `context-policy.json` for each attempt. Higher trigger ratios leave
less headroom before the hard input budget and are diagnostic conditions, not
recommended product settings.

```sh
# Rebuild the local and SWE base images first, as above.
docker build -f e2e/VerifiedAgent.Dockerfile -t orbit-e2e:verified-guarded .
ORBIT_E2E_IMAGE=orbit-e2e:verified-guarded \
ORBIT_E2E_STRATEGY=verified-focused-v1 \
ORBIT_SWE_CASE=e2e/swebench/django__django-15731.json \
npm run eval:swebench -- solve ornith-1.5:9b
```

Use `verified-tests-v1` with the same image, case and generation settings for a
comparison that changes only the completion instructions. Each solve creates a
new Session and workspace. Grade each saved prediction with the pinned official
harness as above. Compare runtime completion, official resolution and independent
quality separately; a budget stop does not make a resolved patch unresolved.
One attempt per condition is diagnostic evidence, not a model ranking or a
statistically established improvement. Historical runs with different dependency
images cannot isolate the effect of the new prompt.

Verify preflight rejection and independent quality classification without model
inference (requires the rebuilt Verified Docker image):

```sh
ORBIT_E2E_IMAGE=orbit-e2e:verified-guarded npm run test:e2e:verified-checks
```

These controls cover a missing source import, failing added and modified tests,
a baseline failure, and preservation of unwanted files for review.

The Verified image also exports `SHELLOPTS=pipefail`. Orbit's Bash tool now
starts with both errexit and pipefail, preserving unhandled failures through log
filters and stopping before later successful commands. Explicit shell error
handling can still suppress a failure; independent quality checks remain
necessary. Some pipelines such as `grep | head` can return nonzero after SIGPIPE;
examine the recorded output rather than treating every nonzero status as a
repository test failure. See [Bash semantics](tools.md#bash).

## Coding workflow evaluation

The opt-in coding workflow suite runs the same 16-card memory game through
three Orbit workflows, based on the English edition of _AI Coding Agent Fundamentals_ and
its [pinned starter templates](../e2e/coding-workflows/README.md):

| Case   | Inputs and execution                                                                                                                                                                                                                                  |
| ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `vibe` | Starter and natural-language game prompt, without a game specification or test plan.                                                                                                                                                                  |
| `sdd`  | First reviews `spec.md` with `test.md` deliberately absent. The host rejects changed or added review files. A fresh implementation Run receives the review, a frozen specification with the book's selected clarifications, and the common test plan. |
| `loop` | Starter, `spec.md`, `test.md`, and `progress.md`; one Run iterates implementation and verification and records progress. Specifications must remain unchanged.                                                                                        |

```sh
npm run test:e2e:coding-workflows:unit
npm run e2e:coding-workflows:build
npm run test:e2e:coding-workflows:graders
ORBIT_E2E_MODELS=ornith-1.5:9b npm run test:e2e:coding-workflows
# Select just one workflow:
ORBIT_E2E_CASE=sdd ORBIT_E2E_REPETITIONS=1 npm run test:e2e:coding-workflows
```

The build installs the upstream locked TypeScript/Vite/Vitest stack on pinned
Node 24 and a separately locked Chromium/Playwright grader. It requires network
access; trial dependencies are preinstalled. The default is one trial per style
with `ornith-1.5:9b`, run serially. Existing small-case defaults are unchanged.
`ORBIT_E2E_MODELS`, `ORBIT_E2E_REPETITIONS` (1–10), `ORBIT_E2E_CASE`, and
`ORBIT_E2E_ROUNDS` (default `unlimited`) select the matrix.
`ORBIT_CODING_WORKFLOWS_ELAPSED_MS` defaults to `unlimited`; a positive
millisecond value restores a finite deadline. Both settings apply to SDD review
and implementation.
Review and implementation explicitly request the model context window discovered
from Ollama `/api/show` metadata. There is no fixed 16K/32K context ceiling and no
fallback for unknown capacity. The requested window is recorded in
`environment.json` and each phase's `input/config.json`; the worker resolves it
against provider capacity and records `output/context-policy.json`. The larger
runtime allocation must fit the local Ollama host; a load failure is reported
rather than silently reducing the window. Unlimited rounds also remove the derived
model-call and tool-request ceilings; unlimited elapsed time disables the host
execution timer. Cleanup, grader and container resource limits remain finite.
Full diagnostic payload capture lasts at most 24 hours for an unlimited trial;
metadata continues afterward.
The SDD review and implementation use separate Sessions, with the review answer
explicitly carried forward. Compare their combined costs with the other styles.
The shared host's generation settings, cleanup, and resource limits apply.
`ORBIT_E2E_IMAGE` overrides `orbit-e2e:coding-workflows-agent` and
`ORBIT_CODING_WORKFLOWS_GRADER_IMAGE` overrides `orbit-e2e:coding-workflows-grader`.
Each trial resolves both images to IDs at startup and uses those IDs for
subsequent agent and grader containers. If an image is removed during a long
trial, grading reports an environment error with checks marked `not-run`.
Compaction and summary attempts, failures, durations, and token counts are
recorded as metadata-only diagnostic events and summarized in run metrics.

This harness uses fixed, preselected review decisions instead of a person
interactively selecting findings. The review is instructed to read only and its
final workspace is checked; it does not implement Codex Plan mode or prove that
no transient writes occurred. Loop iteration is inside a single Orbit Run, without an external retry loop. Browser work remains pending in the
agent's report. Unchanged progress or checked-off browser items in the supplied
progress checklist fail the Loop checks; this is not a semantic audit of every
claim in prose.

A shared observation contract adds `data-testid` hooks for cards, reset, move
count, and completion, plus card state and visible-symbol attributes. These
requirements and a nonzero-test requirement are supplied equally to all three
styles. They make the evaluation reproducible but add constraints beyond the
original Vibe prompt from the source book. They do not prescribe internal TypeScript APIs.

After each implementation the host checks frozen files and runs a fresh,
network-disabled grader container. It invokes the installed type checker,
Vitest (rejecting zero tests), and Vite build directly, then exercises Chromium
against the production preview. It checks a 4-by-4 board at 320px, keyboard
selection, move accounting, immediate matching, input locking, the 799/800ms
mismatch boundary, completion, reset, and cancellation of old timers. It requires
all eight symbols to occur twice and accessible card labels. It does not certify
visual quality, screen-reader behavior, shuffle quality, every spec item, or the
quality of agent-authored unit tests. Card-state attributes are a cooperative
observation interface, not proof against a deliberately deceptive application.
Rare decks that never exercise a required branch fail coverage rather than
silently passing. External model access is available to the solver for Ollama;
the no-web instruction is not a network allowlist.

Grader controls require no model and cover a working game, untouched starter,
zero tests, early mismatch timeout, missing reset cancellation, and a premature
successful process exit. A separate random completion marker prevents exit code
zero alone from passing. Generated code executes only inside the disposable
containers, never in the host process.

Evidence is saved under `tmp/e2e/runs/<timestamp>-coding-workflows/`: pinned template origin,
image IDs, model metadata, prompts, per-phase usage/events, workspace snapshots,
independent grader logs, and an incremental summary with all planned trials.
The summary's `checks` field reports the combined type-check, unit-test, build
and browser verdict (`not-run`, `passed`, or `failed`). Earlier artifacts used
`browser` for that combined verdict; failure there does not establish that the
browser phase ran. Inspect `grade.log` to identify the failing phase.
`run.status`, `fileChecks.status`, and `grading.status` report execution,
protected-file checks, and independent grading separately. The top-level
status preserves a failed Run's `runtime-error`, `timeout`, or
`environment-error` even when grading also fails; `grading-error` applies when
the Run completed but the grader could not produce a usable result.
`resolved` requires both clean runtime completion and passing independent checks;
a budget stop is reported as `runtime-error` even if some artifacts work. Adding these
cases does not establish successful model results; run and retain the matrix
before making claims about workflow effectiveness. These test-local additions
change no Orbit product APIs or runtime policies.

Book workers derive an enabled context budget from model metadata and their
configured `num_ctx`, recording `output/context-policy.json`. Completed tool
rounds can be compacted during a single long task; original user inputs and the
newest complete round remain verbatim. This is independent of unlimited Run
budgets and does not increase the selected Ollama context window.

## Fixed context-summary semantic diagnostic

`npm run test:e2e:summary` tests the independent Python grader without model calls.
`npm run eval:context-summary` replays the committed public solver-history fixture
against localhost Ollama (`ornith-1.5:9b`), comparing the prompt at `4eb5701`
with the current commit. Use `-- --candidate-ref <commit>` to pin the candidate.
The replay also reproduces an optional post-source review instruction from the
selected Git ref, so historical instruction-placement trials remain replayable.
This diagnostic does not run a SWE-bench solver or official harness.

The fixture separates `source` from grader-only `expected` values. Only source
messages, a previous untrusted checkpoint and source IDs enter the model prompt;
expected answers and grading rules do not. The grader checks retained saved
edits, the latest bar-only selection failure and remaining verification, and
unsupported claims that an empty passing test proved both markers. These are
conservative English claim checks for this one scenario, not a general truth
verifier. Explicit contradictions and omitted required evidence fail;
unrecognized or negated wording requires review. A `needs-review` result never
counts as a pass. Quotes and negation are deliberately reviewed conservatively.

The output directory records requests/responses, source and prompt hashes,
model metadata, token/timing metrics and `semanticGrade` per condition. Shape,
source-ID validity, output truncation and semantic results remain separate.
The grader cannot prove the correctness of every statement. Review ambiguous
claims against original tool outputs; compare fixed inputs/settings and retain
failed attempts. Repeated runs overwrite this default output directory; pass
`-- --output tmp/e2e/<unique-run>` to preserve each run.

## Structured observation prototype

`npm run test:e2e:observations` validates an evaluation-only extraction and
consumer-grading path. `npm run eval:context-observations -- --output tmp/e2e/<unique-run>` compares the same faulty checkpoint with and without a
bounded source-derived observation view, three repetitions per condition by
default. It is a downstream interpretation diagnostic, not a new summarizer or
SWE-bench solver. The baseline lacks observations that the checkpoint omitted;
this deliberately tests information preservation, not equal-size prompts.

Only results linked to a specific parent message and call ID become observations;
reused call IDs cannot match results from another call group. The trace must be
known to originate from the built-in tools; names alone do not authenticate a
custom or MCP tool. Confirmed writes retain result paths, source IDs and ordering.
The view retains the latest result and latest successful write per path, plus the
last three commands. It reports omissions and refuses an oversized view instead
of silently truncating it. A write is saved at that operation, not guaranteed to
be the current file state. Shell changes and external changes remain unknown.
The original ledger preserves all observed operations; cancelled requests without
results produce none. Each source is extracted independently, without global state.

Arbitrary Bash stdout remains quoted data, not a parsed test verdict. The optional
`orbit-test --pytest-junit -- <pytest argv>` captures JUnit testcase counts and a
report hash outside the target workspace while preserving the command exit code.
Counts do not prove assertion coverage; that field remains `unknown`. A zero-test
report plus a nonzero command exit is not a pass. Deselection totals are not
provided by this adapter. Missing, inconsistent or oversized reports are recorded
as unavailable, without replacing a timeout/failure exit code. The flag applies
only to the evaluation runner; it changes no Orbit public tool contract.

The consumer model receives the faulty checkpoint and, for the added-observation
condition, only the deterministic view. Expected values and grading rules are
never supplied to it. The fixed consumer grader checks the observed saved path,
latest bar-only selection, and absence of an unsupported verified-behavior claim.
It checks source IDs and completion separately. This is still one English history,
not a general semantic truth verifier, integrity proof or release benchmark.

### Check core observations independently of model answers

Budgeted solver runs emit `context.observations.prepared` diagnostics. Validate
those projected save/process records directly against canonical solver entries:

```sh
npm run test:e2e:core-observations
npm run eval:core-observations -- \
  --result <solver-output>/result.json \
  --events <solver-output>/events.jsonl \
  --output tmp/e2e/core-observations-check.json
```

`not-exercised` means no projection diagnostic was recorded; it is not a passing
projection trial. This checker tests correspondence in controlled runtime
artifacts, not journal cryptographic authentication, current file contents or
behavioral correctness. The core tests separately verify runtime provenance and
persistent/reopened journal binding. Model-consumer scores from the fixed-history
replay remain separate; that replay assumes known legacy-fixture provenance and
does not retroactively authenticate its old Session records.

### Live reopened projection diagnostic

The short diagnostic below separates real tool acknowledgements from model
prose. A fixed setup model executes two real built-in writes in a persistent
Session. The setup model's filler forces a later checkpoint; it is not a coding
ability measurement. After closing and reopening, real Ollama performs summary
and consumer requests, with tools disabled and a diagnostic-only 3,500/2,500
trigger/target. This exercises the actual core provenance/projection path even
when a long solver trial cannot activate a checkpoint.

Run it after other Ollama evaluations have completed. Build the current local
agent image and use a fresh output directory:

```sh
docker build -f e2e/Dockerfile -t orbit-e2e:local .
mkdir -p tmp/e2e/observations-live-new
docker run --name orbit-observations-live --user node \
  -v "$PWD/e2e/observations-live.mjs:/opt/orbit/e2e/observations-live.mjs:ro" \
  orbit-e2e:local node /opt/orbit/e2e/observations-live.mjs
docker cp orbit-observations-live:/output/. tmp/e2e/observations-live-new/
docker rm orbit-observations-live
npm run eval:core-observations -- \
  --result tmp/e2e/observations-live-new/observations-live/result.json \
  --events tmp/e2e/observations-live-new/observations-live/events.jsonl \
  --output tmp/e2e/observations-live-new/check.json
```

The actual model stage has a 300-second Run deadline. The diagnostic may still
produce `not-exercised` if the model summary fails validation; record this
separately from a failed source-correspondence check. This is neither a reference
patch check nor an official SWE-bench solve. The forced thresholds are not a
production tuning recommendation.

For controlled summary recovery diagnostics, add
`-e ORBIT_E2E_SUMMARY_FAULT=empty` or
`-e ORBIT_E2E_SUMMARY_FAULT=missing-fields` to the `docker run` command.
Use a fresh container/output directory per condition. The driver replaces only
its first invoked summary response with a fixed invalid object; subsequent
summary regeneration and the consumer use real Ollama. `injected-fault.json`
records the intervention. Treat these as fault-injection trials, never as
naturally occurring model errors or coding benchmark attempts. Inspect the
`context.summary.validation-failed` event, accepted checkpoint, source-view
correspondence and final runtime separately. The injected response has no real
provider token usage; real response usage remains separate.

The `expanded-missing` diagnostic uses a 4,096-token reserve and injects two responses: first output exhaustion, then a missing category at the expanded allowance. The third summary response and consumer use actual Ollama. This checks that correction retains the expanded allowance, not the natural frequency of this sequence. The output records the count of injected responses.
